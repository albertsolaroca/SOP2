#pragma once

void save_tree(rb_tree *tree, char *filename);
rb_tree *load_tree(char *filename);
