#pragma once

void consult_max_numtimes(rb_tree *tree);
void consult_word_numtimes(rb_tree *tree, char *word);
