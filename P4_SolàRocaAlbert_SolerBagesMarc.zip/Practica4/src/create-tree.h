#pragma once

rb_tree *create_tree(char *fname_dict, char *fname_db);

